Quick copy

<!--ik ben aan den dezen nog nie echt begonnen, wacht... shit ik heb alles op mijn oude versie hiervan gezet, secontje...

-->

<!-- en wa denkte drvan? schoon eh? Hier moet de online winkel komen, ma kben nog nie zeker of dak da wel ga doen.
     da ga zeer irritant zijn in het begin. misschien ga ik de website starten zonder de webstore 
    en pas na een maand ofzo in ons bedrijf zal de webstore open gaan. da lijkt nog een cava idee.-->

<!-- deze kleur was niet gevonden door puur toeval -->

<!-- een verwijzing naar een van de beste parody/humoristische groepen die er bestaan: Steel Panther -->

<!--ik ga hier nog veel aan moeten werken als ik wil dat dit eruit ziet zoals ik het in mijn hoofd heb.
elke keuze(zoals desktops, laptops en andere links) moeten rollover
- afbeeldingen worden die donkerder worden waneer je erover heen gaat met je muis en nog donkerder wanneer je ze inklikt
oe zot is da wel nie... -->
<!--voila, tis terug.aaah da voelt goe.alles terug op zijn plaats, ik had nooit gedacht da de webpagina het meeste werk zou zijn, ik dacht altijd da
da voort marktonderzoek zou zijn maar ja, blijkbaar nie.blijkbaar is het dit dat mij het langste bezig houdt.ook het feit dat ik mij normaalgezien verveel tijdens
gip, wat er voor zorgt dat teksten zoals deze getypt worden.het heeft natuurlijk ook zijn voordelen, ik weet nu namelijk wat de tag is voor een comment te zetten in uw
eigen html document en ik kan nu ook veel sneller typen maar behalve dat, ... vooruitgang in mijn droom om journalist te worden tijdens mijn vrije tijd.
ik moet mijzelf gewoon afleren om telkens in dialect te typen, das mijn achillespees.HA, hoe zot was da, ik heb gewoon een verwijzing gemaakt naar griekse mythologie
terwijl ik eigenlijk aan mijn webpagina moet werken voor mijn gip wat ik negeerde en gewoon begon te schrijven over mijn interesse in journalistiek.ik zou natuurlijk
geen politiek journalist worden, dat is net wat te depressief.ook geen oorlogs of andere drama.meer iets met technologie of games, zoals dorkly en giantbomb.ik moet
natuurlijk nog een hele grote weg afleggen voordat dat soort dingen mijn job zouden kunnen worden maar dat zie ik ook wel zitten, ik wil gewoon ook nog een andere bezigheid
in de tussentijd, zoals games, computers en internet. 3 van de beste uitvindingen.enkel tv mist van die lijst omdat ik dat op dit punt gewoon bij internet zet,
ik kijk altijd naar mijn tv series op netflix en kijk ze in een keer uit.het is een beetje teveel gevraagd om mijn leef schema aan te passen op dat van gewone tv.
meeste mensen zeggen dat neem het gewoon op, wat ik dan ook probeer.ik heb onlangs captain america opgenomen en nog altijd had ik verschillende problemen met het
systeem dat telenet aanbied, ik moest doorheen 20 minuten reclame spoelen ongeveer 4 tot 6 keer verspreid in de film.hoe komt het dat netflix, een service die veel minder
kost mij veel minder problemen veroorzaakt dan telenet die zelfs de regels van net neutraliteit niet respecteren in belgie.Onze isp in belgie suckken, we moeten gewoon
wachten totdat google fiber hier is en dan is ons internet 50 keer zo snel als ervoor, ik zal eindelijk street fighter en marvel kunnen spelen zonder lag en gedropte
inputs en skypen zal ook veel vloeiender gaan + hd functie in netflix zal eindelijk gebruikt worden.djeezus, ik hou echt van typen, aangezien de balk tekst hierboven
lijkt het erop dat ik en de meester van typen over niets ben en de meester van procrastinatie... Yuss tis speeltijd eindelijk 10 minuutjes pauze, of 15 afhankelijk van
hoelang hij duurt dit jaar aangezien onze directeur elk jaar het schema verandert.
-->



fonts:

in tag bv <p> :
segoe ui : style="font-family:'Segoe UI'; font-size:xx-large;"